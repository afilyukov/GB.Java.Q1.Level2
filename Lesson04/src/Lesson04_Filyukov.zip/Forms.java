public class Forms {
    public static void main(String[] args) {
        new ChatForm("Chat");
    }
}
